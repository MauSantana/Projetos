package com.towork.backendaplicacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendAplicacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
