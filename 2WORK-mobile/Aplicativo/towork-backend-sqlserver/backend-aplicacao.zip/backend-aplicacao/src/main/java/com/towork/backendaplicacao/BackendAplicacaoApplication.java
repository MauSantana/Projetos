package com.towork.backendaplicacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendAplicacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendAplicacaoApplication.class, args);
	}

}
